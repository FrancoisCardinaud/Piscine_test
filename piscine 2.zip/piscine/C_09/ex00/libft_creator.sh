#!/bin/bash -e
gcc *.c -c -Wall -Werror -Wextra
ar rc libft.a *.o
ranlib libft.a
rm *.o
