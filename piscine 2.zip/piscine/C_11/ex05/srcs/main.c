/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fcardina <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/09/26 15:37:54 by fcardina          #+#    #+#             */
/*   Updated: 2022/09/27 13:47:55 by fcardina         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft.h"
#include <unistd.h>

int	check_params(int argc, char **argv)
{
	if (argc != 4)
		return (0);
	if (ft_getnbr(argv[1]) == 0 && ft_getnbr(argv[3]) == 0)
		return (0);
	return (1);
}

int	operator(int a, char *c, int b)
{
	int	r;

	r = 1;
	if (c[0] == '+')
		r = ft_add(a, b);
	else if (c[0] == '-')
		r = ft_sub(a, b);
	else if (c[0] == '*')
		r = ft_mul(a, b);
	else if (c[0] == '/')
		r = ft_div(a, b);
	else if (c[0] == '%')
		r = ft_mod(a, b);
	return (r);
}

int	ft_atoi(char *str)
{
	int	sign;
	int	result;
	int	i;

	sign = 1;
	result = 0;
	i = 0;
	while (str[i] && (str[i] == '\f' || str[i] == '\t' || str[i] == ' '
			|| str[i] == '\n' || str[i] == '\r' || str[i] == '\v'))
		i++;
	while (str[i] && (str[i] == '+' || str[i] == '-'))
	{
		if (str[i] == '-')
			sign *= -1;
		i++;
	}
	while (str[i] && str[i] >= '0' && str[i] <= '9')
	{
		result *= 10;
		result += str[i] - '0';
		i++;
	}
	result *= sign;
	return (result);
}

void	do_op(char *n, char *c, char *m)
{
	int	i;
	int	a;
	int	b;

	i = 0;
	a = ft_atoi(n);
	b = ft_atoi(m);
	if (!(c[0] == '+' || c[0] == '-' || c[0] == '/' || c[0] == '%'
			|| c[0] == '*'))
		write(1, "0", 1);
	else if (c[0] == '/' && b == 0)
		write(1, "Error: division by zero", 23);
	else if (c[0] == '%' && b == 0)
		write(1, "Error: modulo by zero", 21);
	else
	{
		ft_putnbr(operator(a, c, b));
	}
	write(1, "\n", 1);
}

int	main(int argc, char **argv)
{
	if (!check_params(argc, argv))
	{
		ft_putstr("0");
		return (0);
	}
	do_op(argv[1], argv[2], argv[3]);
	return (0);
}
