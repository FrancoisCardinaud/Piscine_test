int	ft_sub(int a, int b)
{
	return (a - b);
}
