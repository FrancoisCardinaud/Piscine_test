/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rules.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fcardina <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/09/18 19:25:50 by fcardina          #+#    #+#             */
/*   Updated: 2022/09/18 19:25:52 by fcardina         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	check_col_up(int tab[5][5], int pos, int entry[20])
{
	int	i;
	int	max_height;
	int	visible_towers;

	i = 0;
	max_height = 0;
	visible_towers = 0;
	if (pos / 5 == 4)
	{
		while (i < 5)
		{
			if (tab[i][pos % 5] > max_height)
			{
				max_height = tab[i][pos % 5];
				visible_towers++;
			}
			i++;
		}
		if (entry[pos % 5] != visible_towers)
			return (1);
	}
	return (0);
}

int	check_row_right(int tab[5][5], int pos, int entry[20])
{
	int	i;
	int	max_height;
	int	visible_towers;

	i = 5;
	max_height = 0;
	visible_towers = 0;
	if (pos % 5 == 4)
	{
		while (--i >= 0)
		{
			if (tab[pos / 5][i] > max_height)
			{
				max_height = tab[pos / 5][i];
				visible_towers++;
			}
		}
		if (entry[15 + pos / 5] != visible_towers)
			return (1);
	}
	return (0);
}

int	check_col_down(int tab[5][5], int pos, int entry[20])
{
	int	i;
	int	max_height;
	int	visible_towers;

	i = 4;
	max_height = 0;
	visible_towers = 0;
	if (pos / 5 == 4)
	{
		while (i >= 0)
		{
			if (tab[i][pos % 5] > max_height)
			{
				max_height = tab[i][pos % 5];
				visible_towers++;
			}
			i--;
		}
		if (entry[5 + pos % 5] != visible_towers)
			return (1);
	}
	return (0);
}

int	check_row_left(int tab[5][5], int pos, int entry[20])
{
	int	i;
	int	max_height;
	int	visible_towers;

	i = 0;
	max_height = 0;
	visible_towers = 0;
	if (pos % 5 == 4)
	{
		while (i < 5)
		{
			if (tab[pos / 5][i] > max_height)
			{
				max_height = tab[pos / 5][i];
				visible_towers++;
			}
			i++;
		}
		if (entry[10 + pos / 5] != visible_towers)
			return (1);
	}
	return (0);
}

int	check_case(int tab[5][5], int pos, int entry[20])
{
	if (check_row_left(tab, pos, entry) == 1)
		return (1);
	if (check_row_right(tab, pos, entry) == 1)
		return (1);
	if (check_col_down(tab, pos, entry) == 1)
		return (1);
	if (check_col_up(tab, pos, entry) == 1)
		return (1);
	return (0);
}
