/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fcardina <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/09/18 19:25:27 by fcardina          #+#    #+#             */
/*   Updated: 2022/09/18 19:25:31 by fcardina         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int		ft_atoi(char *str);
int		ft_strlen(char *str);
int		*get_numbers(char *str);
int		check(int ac, char **av);
int		check_double(int tab[8][8], int pos, int num);
int		check_case(int tab[8][8], int pos, int entry[32]);
void	ft_putnbr(int nb);
void	ft_putchar(char c);
void	ft_putstr(char *str);

void	display_solution(int tab[8][8])
{
	int	i;
	int	j;

	i = -1;
	while (++i < 8)
	{
		j = -1;
		while (++j < 8)
		{
			ft_putnbr(tab[i][j]);
			ft_putchar(' ');
		}
		ft_putchar('\n');
	}
}

int	check_double(int tab[8][8], int pos, int size)
{
	int	i;

	i = -1;
	while (++i < pos / 8)
		if (tab[i][pos % 8] == size)
			return (1);
	i = -1;
	while (++i < pos % 8)
		if (tab[pos / 8][i] == size)
			return (1);
	return (0);
}

int	solve(int tab[8][8], int entry[32], int pos)
{
	int	size;

	if (pos == 64)
		return (0);
	size = 0;
	while (++size <= 8)
	{
		if (check_double(tab, pos, size) == 0)
		{
			tab[pos / 8][pos % 8] = size;
			if (check_case(tab, pos, entry) == 0)
			{
				if (solve(tab, entry, pos + 1) == 0)
					return (0);
			}
			else
				tab[pos / 8][pos % 8] = 0;
		}
	}
	return (1);
}

int	main(int ac, char **av)
{
	int	tab[8][8];
	int	*entry;
	int	i;
	int	j;

	i = 0;
	j = 0;
	while (i < 8)
	{
		while (j < 8)
		{
			tab[i][j] = 0;
			j++;
		}
		i++;
	}
	if (check(ac, av) == 1)
		return (1);
	entry = get_numbers(av[1]);
	if (solve(tab, entry, 0) == 0)
		display_solution(tab);
	else
		ft_putstr("Did not find any solutions\n");
	return (1);
}
