#!/bin/bash
git ls-files -o -i --exclude-standard