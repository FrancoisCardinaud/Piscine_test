/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strs_to_tab.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fcardina <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/09/21 16:59:04 by fcardina          #+#    #+#             */
/*   Updated: 2022/09/22 16:22:19 by fcardina         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include "ft_stock_str.h"

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
		i++;
	return (i);
}

char	*ft_strcpy(char *str, int size)
{
	char	*cpy;
	int		i;

	cpy = NULL;
	cpy = malloc(sizeof(char) * (size + 1));
	i = 0;
	while (str[i])
	{
		cpy[i] = str[i];
		i += 1;
	}
	cpy[i] = '\0';
	return (cpy);
}

struct	s_stock_str	*ft_strs_to_tab(int ac, char **av)
{
	t_stock_str	*strct;
	int			i;

	strct = (t_stock_str *)malloc(sizeof(t_stock_str) * (ac + 1));
	if (strct == NULL)
		return (NULL);
	i = 0;
	while (i < ac)
	{
		strct[i].size = ft_strlen(av[i]);
		strct[i].str = av[i];
		strct[i].copy = ft_strcpy(av[i], strct[i].size);
		i += 1;
	}
	strct[i].size = 0;
	strct[i].str = 0;
	strct[i].copy = 0;
	return (strct);
}
