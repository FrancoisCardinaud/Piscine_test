/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rules.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fcardina <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/09/18 19:25:50 by fcardina          #+#    #+#             */
/*   Updated: 2022/09/18 19:25:52 by fcardina         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	check_col_up(int tab[8][8], int pos, int entry[32])
{
	int	i;
	int	max_height;
	int	visible_towers;

	i = 0;
	max_height = 0;
	visible_towers = 0;
	if (pos / 8 == 7)
	{
		while (i < 8)
		{
			if (tab[i][pos % 8] > max_height)
			{
				max_height = tab[i][pos % 8];
				visible_towers++;
			}
			i++;
		}
		if (entry[pos % 8] != visible_towers)
			return (1);
	}
	return (0);
}

int	check_row_right(int tab[8][8], int pos, int entry[32])
{
	int	i;
	int	max_height;
	int	visible_towers;

	i = 8;
	max_height = 0;
	visible_towers = 0;
	if (pos % 8 == 7)
	{
		while (--i >= 0)
		{
			if (tab[pos / 8][i] > max_height)
			{
				max_height = tab[pos / 8][i];
				visible_towers++;
			}
		}
		if (entry[24 + pos / 8] != visible_towers)
			return (1);
	}
	return (0);
}

int	check_col_down(int tab[8][8], int pos, int entry[32])
{
	int	i;
	int	max_height;
	int	visible_towers;

	i = 7;
	max_height = 0;
	visible_towers = 0;
	if (pos / 8 == 7)
	{
		while (i >= 0)
		{
			if (tab[i][pos % 8] > max_height)
			{
				max_height = tab[i][pos % 8];
				visible_towers++;
			}
			i--;
		}
		if (entry[8 + pos % 8] != visible_towers)
			return (1);
	}
	return (0);
}

int	check_row_left(int tab[8][8], int pos, int entry[32])
{
	int	i;
	int	max_height;
	int	visible_towers;

	i = 0;
	max_height = 0;
	visible_towers = 0;
	if (pos % 8 == 7)
	{
		while (i < 8)
		{
			if (tab[pos / 8][i] > max_height)
			{
				max_height = tab[pos / 8][i];
				visible_towers++;
			}
			i++;
		}
		if (entry[16 + pos / 8] != visible_towers)
			return (1);
	}
	return (0);
}

int	check_case(int tab[8][8], int pos, int entry[32])
{
	if (check_row_left(tab, pos, entry) == 1)
		return (1);
	if (check_row_right(tab, pos, entry) == 1)
		return (1);
	if (check_col_down(tab, pos, entry) == 1)
		return (1);
	if (check_col_up(tab, pos, entry) == 1)
		return (1);
	return (0);
}
