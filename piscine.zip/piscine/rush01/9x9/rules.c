/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rules.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fcardina <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/09/18 19:25:50 by fcardina          #+#    #+#             */
/*   Updated: 2022/09/18 19:25:52 by fcardina         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	check_col_up(int tab[9][9], int pos, int entry[36])
{
	int	i;
	int	max_height;
	int	visible_towers;

	i = 0;
	max_height = 0;
	visible_towers = 0;
	if (pos / 9 == 8)
	{
		while (i < 9)
		{
			if (tab[i][pos % 9] > max_height)
			{
				max_height = tab[i][pos % 9];
				visible_towers++;
			}
			i++;
		}
		if (entry[pos % 9] != visible_towers)
			return (1);
	}
	return (0);
}

int	check_row_right(int tab[9][9], int pos, int entry[36])
{
	int	i;
	int	max_height;
	int	visible_towers;

	i = 9;
	max_height = 0;
	visible_towers = 0;
	if (pos % 9 == 8)
	{
		while (--i >= 0)
		{
			if (tab[pos / 9][i] > max_height)
			{
				max_height = tab[pos / 9][i];
				visible_towers++;
			}
		}
		if (entry[27 + pos / 9] != visible_towers)
			return (1);
	}
	return (0);
}

int	check_col_down(int tab[9][9], int pos, int entry[36])
{
	int	i;
	int	max_height;
	int	visible_towers;

	i = 8;
	max_height = 0;
	visible_towers = 0;
	if (pos / 9 == 8)
	{
		while (i >= 0)
		{
			if (tab[i][pos % 9] > max_height)
			{
				max_height = tab[i][pos % 9];
				visible_towers++;
			}
			i--;
		}
		if (entry[9 + pos % 9] != visible_towers)
			return (1);
	}
	return (0);
}

int	check_row_left(int tab[9][9], int pos, int entry[36])
{
	int	i;
	int	max_height;
	int	visible_towers;

	i = 0;
	max_height = 0;
	visible_towers = 0;
	if (pos % 9 == 8)
	{
		while (i < 9)
		{
			if (tab[pos / 9][i] > max_height)
			{
				max_height = tab[pos / 9][i];
				visible_towers++;
			}
			i++;
		}
		if (entry[18 + pos / 9] != visible_towers)
			return (1);
	}
	return (0);
}

int	check_case(int tab[9][9], int pos, int entry[36])
{
	if (check_row_left(tab, pos, entry) == 1)
		return (1);
	if (check_row_right(tab, pos, entry) == 1)
		return (1);
	if (check_col_down(tab, pos, entry) == 1)
		return (1);
	if (check_col_up(tab, pos, entry) == 1)
		return (1);
	return (0);
}
