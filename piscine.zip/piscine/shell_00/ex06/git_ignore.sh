#!/bin/bash
git ls-files --others